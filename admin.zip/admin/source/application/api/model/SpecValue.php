<?php

namespace app\api\model;

use app\common\model\SpecValue as SpecValueModel;

/**
 * 规格/属性(值)模型
 * Class SpecValue
 * @package app\api\model
 */
class SpecValue extends SpecValueModel
{
}
