<?php

namespace app\common\model;
/**
 * 商品模型
 * Class Goods
 * @package app\common\model
 */
class Dexx extends BaseModel
{
    protected $name = 'dexx';

}