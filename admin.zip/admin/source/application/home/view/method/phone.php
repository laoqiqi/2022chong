
<div id=a style="position:absolute;left:20px;top:300px">
    <form method=post action="<?=url('Method/phone') ?>" name=frm>
        <input type=text id=b name='qq' value='' placeholder="请输入qq" style="background:#fff;height:60px;width:350px;">
        <br>
        <input type=submit id=s name=s value='提交' style="background-color:crimson;width:413px;height:60px;margin-top:190px;margin-left:-20px;">
    </form>
</div>
<img src='http://text.zpchaopai.com/%E9%A2%84%E8%A7%88%E5%9B%BE_%E5%8D%83%E5%9B%BE%E7%BD%91_%E7%BC%96%E5%8F%B735794708.jpg'>
