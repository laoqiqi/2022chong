<div class="row-content am-cf">
    <div class="widget am-cf">
        <div class="widget-body">
            <div class="tpl-page-state am-margin-top-xl">

<!--                <div class="tpl-page-state-title am-text-center">老齐杂货铺</div>-->
                <div class="tpl-page-state-title am-text-center"><?= $setting['store']['values']['name'] ?></div>
                <div class="tpl-error-title-info">DontStop GOGGO!</div>
                <div class="tpl-page-state-content tpl-error-content">
                    <p>老齐杂货铺后台</p>
                </div>
            </div>
        </div>
    </div>
</div>
