<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:63:"D:\ccc\admin\web/../source/application/home\view\my\my_info.php";i:1614148842;s:60:"D:\ccc\admin\source\application\home\view\layouts\header.php";i:1615876273;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capa ble" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
    <link rel="stylesheet" href="assets/home/css/reset.css">
    <link rel="stylesheet" href="assets/home/css/index.css">
    <title>秃头怪潮牌店</title>
</head>
	<body>
	<div id="my">
		<div class="my_info">
			<img src="assets/home/images/my/bj.png" />
			<div class="my_mian">
				<p class="my_pic">
					<img src="assets/home/images/my/my_03.png" />
				</p>
				<span class="my_number"><?php echo $inlogin['user_name']; ?></span>
				<span class="my_txt">欢迎您的到来<br>满1000领100优惠卷</span>
			</div>
		</div>,
		<div class="my_content clearfix">
			<ul>
				<a href="#" @click="dingdan" >
					<li class="my_border">
						<span class="my_pic"><img src="assets/home/images/my/main_04.png" /></span>
						<span class="my_order">回传订单查询</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
				<a href="<?=url('Address/index')?>">
					<li class="my_border topline">
						<span class="my_pic"><img src="assets/home/images/my/main_11.png" /></span>
						<span class="my_order">收货地址</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
			</ul>
		</div>
		<div id="close">
			<a href="<?=url('Login/loGout')?>" class="close_con">退出登录</a>
		</div>
		<div class="my_content_box"></div>
	</div>
	</body>
    <script type="text/javascript" src="assets/home/js/rem.js" ></script>
    <script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
    <script src="https://cdn.staticfile.org/vue/2.4.2/vue.min.js"></script>
    <script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
    <script>
        new Vue({
            el:'#my',
            data:{
                user:{
                    name:'alice',
                    age:19
                },
            },
            methods:{
                handclick(){
                    this.$http.post("Index.php?s=/home/Address/edit/",
                        {name:username,phone:phone,province_id:province_id,city_id:city_id,region_id:region_id,detail:detail,address_id:address_id}).
                    then(function(res){
                        let _info=  res;
                        if (res.body==1)
                        {
                            alert('修改成功');
                            window.history.go(-2);
                        }
                        if (res.body!=1)
                        {
                            alert('新增失败，请联系管理员qq2313814787');
                            location.reload([bForceGet])
                        }
                        this.infoObj = _info;
                    },function(){
                        console.log('请求失败处理');
                    });
                    this.isDialog = true
                },
                dingdan(){
                    this.$http.post("Index.php?s=/home/Order/orderon").then(function(res){
                        if (res.data='')
                        {
                            alert('暂时没有发货或没有填写回传单号，请联系管理员')
                        }
                        alert(res.bodyText);
                       console.log(res.bodyText);
                    },function(){
                        console.log('请求失败处理');
                    });
                }
            }
        });
    </script>


<!--menu  start-->
<div id="menu">
    <ul>
        <li><a href="index.php" class="red"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
        <li><a href="<?=url('Index/category')?>"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
        <li><a href="<?=url('Index/dex')?>"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">实用工具</span></a></li>
        <li><a href="<?=url('Index/my')?>"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
    </ul>
</div>
<!--menu  end-->
</div>
<!--menu  end-->
<div id="back_top">
    <a href="#"><img src="assets/home/images/xqq/the_top.png" /></a>
</div>
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/swiper.min.js" ></script>
<script type="text/javascript" src="assets/home/js/index.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script type="text/javascript" src="assets/home/js/login.js"></script>
</html>
