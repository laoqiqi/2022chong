<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\ccc\admin\web/../source/application/home\view\success\success_order.php";i:1605601335;}*/ ?>

<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="format-detection" content="telephone=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
		<link rel="stylesheet" href="assets/home/css/reset.css">
		<link rel="stylesheet" href="assets/home/css/index.css">
		<title>Success_order</title>
	</head>
	<body>
		<div id="wrapper">
			<div class="int_title"><span class="int_pic"><img src="assets/home/images/jifen/left.png"/></span>购买成功</div>
			<div class="m_pwd success_main">
				<div class="success topline">
					<div class="success_boox">
						<p class="s_pic clearfix">
							<span class="s_p_img fl"><img src="assets/home/images/index/dd_03.png" style="margin-left:47px;"/></span>
							<span class="s_p_txt fr">交易成功!感谢金主爸爸</span>
						</p>
						<div class="s_text">
							<p class="s_t_con">
							</p>
							<p class="s_t_main" style="margin-top:166px;">
								<span>订单号：四点之前六点出单号，过了十二点第二天</span>
								<span>商品  ：耐克aj1</span>
								<span>尺寸  ：42</span>
								<span>用户名：齐文</span>
								<span>付款  ：299</span>
							</p>
                            <img src="<?php echo $data['file_url']; ?>/<?php echo $data['file_name']; ?>">
						</div>
					</div>
				</div>

			</div>
		</div>
			<script type="text/javascript" src="assets//home/js/rem.js" ></script>
	</body>
</html>
