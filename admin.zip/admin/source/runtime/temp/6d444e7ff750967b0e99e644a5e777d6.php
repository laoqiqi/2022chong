<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:74:"/www/wwwroot/ccc/admin/web/../source/application/home/view/order/order.php";i:1607496770;s:70:"/www/wwwroot/ccc/admin/source/application/home/view/layouts/header.php";i:1607492902;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
    <link rel="stylesheet" href="assets/home/css/reset.css">
    <link rel="stylesheet" href="assets/home/css/index.css">
    <title>秃头怪潮牌店</title>
</head>




<body>
		<div id="wrapper" class="m_pwd">
			<!--<h2 class="int_title clearfix"><span class="int_pic"><img src="images/jifen/left.png"/></span>积分商城</h2>-->
			<div class="int_title"><span class="int_pic"><img src="assets/home/images/jifen/left.png"/></span>订单详情</div>
				<div class="fill_order clearfix">
					<ul class="fill_box">
						<li class="fill_left fill_list fl">
							<span class="fill_span"><?=$data['name'] ?>  <?=$data['phone'] ?></span>
							<p class="fill_pic clearfix">
								<span class="span_pic fl"><img src="assets/home/images/ddxq/icon.png"></span>
								<span class="span_text fr"><?=$data['detail'] ?></span>
							</p>
						</li>
						<li class="fill_right fill_list fr">
							<img src="assets/home/images/ddxq/right.png" class="fill_img" />
						</li>
					</ul>
				</div>
			<!--banner start-->
            <form action="<?=url('index/zhiFun')?>" method="post">
			<div class="order">
				<p class="o_txt clearfix">
					单号 :发货后自动回传，请在我的界面查询
				</p>
				<dl class="order_box topline clearfix">
					<dt class="order_pic fl">
						<img src="<?php echo $goodsinfo['file_url']; ?>/<?php echo $goodsinfo['file_name']; ?>"  style="height:147px;"/>
					</dt>
					<dd class="order_txt fr">
						<p class="order_con">商品名字：<?= $goodsinfo['goods_name'] ?>
                         <input name="goods_id" value="<?= $goodsinfo['goods_id'] ?>" style="display: none">
                        </p>
                        <input name="address_id" value="<?= $data['address_id'] ?>" style="display: none">
                        <p class="order_con">价格：<?= $goodsinfo['goods_price'] ?></p>
						<span class="order_line">请填写码数:
                            <input class="number"  placeholder="点我填写码数" style="height:50px;" name="number">
                        </span>
                        <span class="order_line">备注几号:
                            <input class="number"  placeholder="点我填写几号鞋子"  name="int">
                        </span>
                        <button style="margin-top:16px;width:200px; padding:8px;background-color: #428bca;border-color: #357ebd;color: #fff;-moz-border-radius: 10px;-webkit-border-radius: 10px;
                         border-radius: 10px;-khtml-border-radius:10px;text-align: center;vertical-align: middle; border: 1px solid transparent;font-weight: 900;font-size:125%">点击购买</button>
						<p class="order_number clearfix"><span class="order_add fr">x1</span></p>
					</dd>
				</dl>
			</div>
            </form>
            <img src="assets/home/images/ddxq/kefu.png" style="width:411px;margin-left: 2px;margin-top: 76px;">
         </div>
        <script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js"></script>
<script>
    $('.int_pic').click(function(){
        window.history.go(-1);
    })
</script>
</body>


<!--menu  start-->
<div id="menu">
    <ul>
        <li><a href="index.php" class="red"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
        <li><a href="<?=url('Index/category')?>"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
        <li><a href="#"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">购物车</span></a></li>
        <li><a href="<?=url('Index/my')?>"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
    </ul>
</div>
<!--menu  end-->
</div>
<!--menu  end-->
<div id="back_top">
    <a href="#"><img src="assets/home/images/xqq/the_top.png" /></a>
</div>
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/swiper.min.js" ></script>
<script type="text/javascript" src="assets/home/js/index.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script type="text/javascript" src="assets/home/js/login.js"></script>
</html>
