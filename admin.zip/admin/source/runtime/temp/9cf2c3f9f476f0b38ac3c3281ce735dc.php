<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"D:\ccc\admin\web/../source/application/home\view\my\my_info.php";i:1604904937;}*/ ?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="format-detection" content="telephone=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
		<link rel="stylesheet" href="assets/home/css/reset.css">
		<link rel="stylesheet" href="assets/home/css/index.css">
		<title>My_info</title>
	</head>
	<body>
	<div id="my">
		<div class="my_info">
			<img src="assets/home/images/my/bj.png" />
			<div class="my_mian">
				<p class="my_pic">
					<img src="assets/home/images/my/my_03.png" />
				</p>
				<span class="my_number">1234567809</span>
				<span class="my_txt">余额：0.00积分</span>
			</div>
		</div>
		<div class="my_content clearfix">
			<ul>
				<a href="../../../../../../html/My_order.html">
					<li class="my_border">
						<span class="my_pic"><img src="assets/home/images/my/main_04.png" /></span>
						<span class="my_order">我的订单</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
				<a href="../../../../../../html/Receipt_info.html">
					<li class="my_border topline">
						<span class="my_pic"><img src="assets/home/images/my/main_11.png" /></span>
						<span class="my_order">收货地址</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
				<a href="../../../../../../html/Account_recharge.html">
					<li class="my_border topline">
						<span class="my_pic"><img src="assets/home/images/my/main_13.png" /></span>
						<span class="my_order">账户充值</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
				<a href="../../../../../../html/Balance_transfer.html">
					<li class="topline">
						<span class="my_pic"><img src=".assets/home/images/my/main_15.png" /></span>
						<span class="my_order">余额转移</span>
						<span class="my_right"><img src="assets/home/images/my/right.png"/></span>
					</li>
				</a>
			</ul>
		</div>
		<div id="close">
			<a href="#" class="close_con">退出登录</a>
		</div>
		<div class="my_content_box"></div>
	</div>
	<!--menu  start-->
	<div id="menu">
		<ul>
			<li><a href="../../../../../../html/index.html"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
			<li><a href="../../../../../../html/AssorTment.html"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
			<li><a href="../../../../../../html/Shopping_Cart.html"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">购物车</span></a></li>
			<li><a href="my_info.php" class="red"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
		</ul>
	</div> 
	<!--menu  end-->
	<script type="text/javascript" src="assets/home/js/rem.js" ></script>
	<script type="text/javascript" src="assets/home/js/menu.js" ></script>
	</body>
</html>
