<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:64:"D:\ccc\admin\web/../source/application/home\view\dex\tiangou.php";i:1616052810;s:60:"D:\ccc\admin\source\application\home\view\layouts\header.php";i:1615876273;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capa ble" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
    <link rel="stylesheet" href="assets/home/css/reset.css">
    <link rel="stylesheet" href="assets/home/css/index.css">
    <title>秃头怪潮牌店</title>
</head>
 <img src="http://text.zpchaopai.com/%E9%A2%84%E8%A7%88%E5%9B%BE_%E5%8D%83%E5%9B%BE%E7%BD%91_%E7%BC%96%E5%8F%B714136698.png" height="100%" width="100%">
 <textarea cols="20" rows="20" style="font-size:18px;background:transparent;border-style:none;float: left;margin-top:-505px;margin-left:119px" readonly><?= $data ?></textarea>
<!--menu  start-->
<div id="menu">
    <ul>
        <li><a href="index.php" class="red"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
        <li><a href="<?=url('Index/category')?>"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
        <li><a href="<?=url('Index/dex')?>"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">实用工具</span></a></li>
        <li><a href="<?=url('Index/my')?>"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
    </ul>
</div>
<!--menu  end-->
</div>
<!--menu  end-->
<div id="back_top">
    <a href="#"><img src="assets/home/images/xqq/the_top.png" /></a>
</div>
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/swiper.min.js" ></script>
<script type="text/javascript" src="assets/home/js/index.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script type="text/javascript" src="assets/home/js/login.js"></script>
</html>
