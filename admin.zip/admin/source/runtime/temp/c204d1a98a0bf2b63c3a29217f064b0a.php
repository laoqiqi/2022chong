<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"D:\ccc\admin\web/../source/application/home\view\login\register.php";i:1607050764;s:60:"D:\ccc\admin\source\application\home\view\layouts\header.php";i:1615876273;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capa ble" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
    <link rel="stylesheet" href="assets/home/css/reset.css">
    <link rel="stylesheet" href="assets/home/css/index.css">
    <title>秃头怪潮牌店</title>
</head>
<body>
<div id="app">
    <div id="my" class="login_content" style="">
        <div class="my_info">
            <img src="assets/home/images/login/bj_01.png" />
            <div class="my_mian login_pic">
            </div>
        </div>
        <div class="login">
                <p class="login_p"><span class="logo_user">
                        <img src="assets/home/images/login/login_04.png"/></span>
                    <input type="text" name="user_name" placeholder="请输入用户名" id="username" autocomplete="off" value=""/></p>
                <p class="login_p"><span class="logo_pwd">
                        <img src="assets/home/images/login/login_07.png"/></span>
                    <input type="password" placeholder="请输入密码"  id="password" name="password" value=""/></p>
                <p class="login_sub"><input @click="handclick" type="submit" id="sub" value="注册"  /></p>
        </div>
    </div>
</div>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script src="https://cdn.staticfile.org/vue/2.4.2/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
</body>
<script>
    new Vue({
        el:'#app',
        data:{
            user:{
                name:'alice',
                age:19
            },
        },
        methods:{
            handclick(){
                username = $('#username').val();
                password  = $('#password').val();
                if (username=='')
                {
                    alert('请正确填写用户名')
                }
                if (password=='')
                {
                    alert('请正确填写密码')
                }
                    this.$http.post("Index.php?s=/home/login/register/",{params:{username:username,password:password}}).then(function(res){
                        let _info=  res;
                        if (res.body==3)
                        {
                            alert('用户名已被使用')
                        }
                        if (res.body==1)
                        {
                            alert('注册成功,跳转登录页');
                            window.history.go(-1);
                        }
                        this.infoObj = _info;
                    },function(){
                        console.log('请求失败处理');
                    });
                    this.isDialog = true
            },
        }
    });
</script>

<!--menu  start-->
<div id="menu">
    <ul>
        <li><a href="index.php" class="red"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
        <li><a href="<?=url('Index/category')?>"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
        <li><a href="<?=url('Index/dex')?>"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">实用工具</span></a></li>
        <li><a href="<?=url('Index/my')?>"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
    </ul>
</div>
<!--menu  end-->
</div>
<!--menu  end-->
<div id="back_top">
    <a href="#"><img src="assets/home/images/xqq/the_top.png" /></a>
</div>
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/swiper.min.js" ></script>
<script type="text/javascript" src="assets/home/js/index.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script type="text/javascript" src="assets/home/js/login.js"></script>
</html>
