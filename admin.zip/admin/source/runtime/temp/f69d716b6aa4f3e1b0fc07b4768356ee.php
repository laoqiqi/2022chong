<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:84:"/www/wwwroot/ccc/admin/web/../source/application/home/view/assorement/assorement.php";i:1607493354;s:70:"/www/wwwroot/ccc/admin/source/application/home/view/layouts/header.php";i:1607492902;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,minimum-scale=1.0">
    <link rel="stylesheet" href="assets/home/css/reset.css">
    <link rel="stylesheet" href="assets/home/css/index.css">
    <title>秃头怪潮牌店</title>
</head>





<body>
<div id="wrapper">
    <!--头部搜索框 start-->
    <div class="wf-search" id="search">
        <header>
            <div class="jd-logo">
                <img src="assets/home/images/logo/xrw-95.png" />
            </div>
            <div class="search">
                <form>
                    <span class="sprite-icon"></span>
                    <input type="search" placeholder="招收代理，记得联系我哦">
                </form>
            </div>
            <div class="login">
                <a href="Receipt_address.html" id="loginmain">
                    秃头
                </a>
            </div>
        </header>
    </div>
    <!--头部搜索框 end-->
    <div class="Integral_mall clearfix">
        <div class="integ_box topline clearfix">
            <div class="integ_left fl">
                <ul class="integ_ul  ">
                    <?php foreach($cateInfo as $first): ?>
                        <a href="<?=url('Index/category',['category_id'=>$first['category_id']])?>">
                            <li class="integ_li" id="<?php echo $first['category_id']; ?>">
                                <?php echo $first['name']; ?>
                                <p class="integ_border"></p>
                            </li>
                        </a>
                    <?php endforeach; ?>
                    <p class="integ_top topline"></p>
                </ul>
            </div>
            <div class="integ_right clearfix fr">
                <ul class="integ_main clearfix" style="display:block;" >
                    <a href="Inner_page.html">
                        <?php foreach($catagoryInfo as $first): ?>
                        <li class="integ_con fl" style="padding-bottom:15px;">
                           <a href="<?=url('index/goodsPage',['goods_id'=>$first['goods_id']])?>">
                               <img src="<?php echo $first['file_url']; ?>/<?php echo $first['file_name']; ?>" style="width:90px;height:100px;">
                           </a>
                            <span class="integ_text"><?php echo $first['goods_name']; ?></span>
                            <div style="display:none" id="category_id"><?php echo $first['category_id']; ?></div>
                        </li>
                        <?php endforeach; ?>
                    </a>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--menu  end-->
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js"></script>
<script src="assets/home/js/fill_name.js"></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>

<script>

    //获取点击事件
    $(document).ready(function () {

           id = $('#category_id').html();
           $('#'+id).addClass('integ_back')

    })

    // $(function(){
    //     console.log(1111111111);
    //     data =   $catagoryInfo[0]['catagoryInfo'];
    //     console.log(data);
    //     $(".data").addClass("intro");
    //     });

</script>
</body>



<!--menu  start-->
<div id="menu">
    <ul>
        <li><a href="index.php" class="red"><font class="iconfont">&#xe612;</font><span class="inco_txt">首页</span></a></li>
        <li><a href="<?=url('Index/category')?>"><font class="iconfont">&#xe660;</font><span class="inco_txt">分类</span></a></li>
        <li><a href="#"><font class="iconfont index">&#xe63e;</font><span class="inco_txt">购物车</span></a></li>
        <li><a href="<?=url('Index/my')?>"><font class="iconfont">&#xe62e;</font><span class="inco_txt">我的</span></a></li>
    </ul>
</div>
<!--menu  end-->
</div>
<!--menu  end-->
<div id="back_top">
    <a href="#"><img src="assets/home/images/xqq/the_top.png" /></a>
</div>
<script type="text/javascript" src="assets/home/js/rem.js" ></script>
<script type="text/javascript" src="assets/home/js/swiper.min.js" ></script>
<script type="text/javascript" src="assets/home/js/index.js" ></script>
<script type="text/javascript" src="assets/home/js/top.js" ></script>
<script type="text/javascript" src="assets/home/js/menu.js" ></script>
<script type="text/javascript" src="assets/home/js/jquery-1.11.3.min.js" ></script>
<script type="text/javascript" src="assets/home/js/login.js"></script>
</html>
