<?php

namespace app\common\model;


class SuccessUpdate extends BaseModel
{
    protected $name = 'success_update';

}
