<?php
namespace app\common\model;

class Visit extends BaseModel
{
    protected  $name = 'visit';
}
